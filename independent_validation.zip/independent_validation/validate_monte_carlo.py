"""
validate_monte_carlo.py -- independent Monte Carlo check of Table 5 (Section 7.3).

Usage:  python validate_monte_carlo.py 1000 10000 100000      (about one minute in total)
Fixed configuration of Section 6.1 (K = 10, SNR 5 dB, cond(M) = 4), 500 trials per sample size.
Random seeds (new, unrelated to the repository's seeds): numpy default_rng(20261008 + T).

In each trial the lagged covariances are estimated from a fresh data set and two
combinations are computed from the estimates:
  MM  the empirical maximal-margin combination, computed exactly by the SDP of
      indep_model.max_margin (the quantity that MMRW approximates to relative tolerance 1e-3);
  PC  the perceptron-type method (Algorithm 2), iteration cap 3000.
For each, with alpha the returned unit direction, it records whether A(alpha) is PD for the
true matrices, lambda_min(A(alpha)), and the whitening defect ||hat Q A(alpha) hat Q - I||_2.
Writes one file mc_T{T}.csv per sample size, one row per trial.
"""
import sys, csv, time, numpy as np
from indep_model import fixed_model, population_matrices, simulate, lagged_estimates, max_margin, pc, assess

NTRIALS = 500; K = 10; SEED_BASE = 20261008
M, V = fixed_model()
A_true = population_matrices(M, K)
for T in [int(x) for x in sys.argv[1:]]:
    rng = np.random.default_rng(SEED_BASE + T); t0 = time.time()
    with open(f'mc_T{T}.csv', 'w', newline='') as f:
        w = csv.writer(f)
        w.writerow(['trial', 'MM_pd', 'MM_lmin', 'MM_defect', 'PC_returned', 'PC_pd', 'PC_lmin', 'PC_defect'])
        for tr in range(NTRIALS):
            Ah = lagged_estimates(simulate(M, V, T, rng), K)
            _, a = max_margin(Ah); mm = assess(a, A_true, Ah)
            a = pc(Ah)
            pcr = assess(a, A_true, Ah) if a is not None else (False, np.nan, np.nan)
            w.writerow([tr, int(mm[0]), repr(float(mm[1])), repr(float(mm[2])), int(a is not None), int(pcr[0]), repr(float(pcr[1])), repr(float(pcr[2]))])
    print('T=%d: %d trials in %.0f s -> mc_T%d.csv' % (T, NTRIALS, time.time()-t0, T))
